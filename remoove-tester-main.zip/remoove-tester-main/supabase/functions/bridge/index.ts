// Supabase Edge Function: bridge
// Proxy to Bridge Sandbox without exposing API key to the browser
// Deno runtime

// CORS helper
function corsHeaders(origin: string | null) {
  return {
    "Access-Control-Allow-Origin": origin || "",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, idempotency-key",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
  };
}

const BRIDGE_API_BASE = Deno.env.get("BRIDGE_API_BASE") || "https://api.sandbox.bridge.xyz";
const BRIDGE_API_KEY = Deno.env.get("BRIDGE_API_KEY");

function jsonResponse(body: unknown, init: ResponseInit = {}, origin: string | null = null) {
  const baseHeaders: Record<string, string> = { "Content-Type": "application/json" };
  const headers = origin ? { ...baseHeaders, ...corsHeaders(origin) } : baseHeaders;
  return new Response(JSON.stringify(body), { ...init, headers });
}

async function handleProxy(req: Request, url: URL) {
  const origin = req.headers.get("origin");

  // CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders(origin) });
  }

  // Health endpoint doesn't require auth
  if (url.pathname.endsWith("/health") && req.method === "GET") {
    return jsonResponse({ sandbox: true, key_present: Boolean(BRIDGE_API_KEY) }, { status: 200 }, origin);
  }

  // Require server key
  if (!BRIDGE_API_KEY) {
    return jsonResponse({ error: "bridge_key_missing" }, { status: 503 }, origin);
  }

  // Auth check (accept mock token in dev)
  const auth = req.headers.get("authorization");
  if (!auth || !auth.startsWith("Bearer ")) {
    return jsonResponse({ error: "forbidden" }, { status: 403 }, origin);
  }
  const token = auth.replace("Bearer ", "");
  // In this sandbox, accept the mock token. Replace with real verification in prod.
  if (token !== "mock-jwt-token") {
    return jsonResponse({ error: "forbidden" }, { status: 403 }, origin);
  }

  try {
    // Route handling
    const path = url.pathname.replace(/^\/functions\/v1\/bridge/, "");

    if (req.method === "POST" && path === "/customers") {
      const body = await req.text();
      const idempotencyKey = crypto.randomUUID();

      const resp = await fetch(`${BRIDGE_API_BASE}/v0/customers`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Api-Key": BRIDGE_API_KEY,
          "Idempotency-Key": idempotencyKey,
        },
        body,
      });

      const data = await resp.text();
      return new Response(data, {
        status: resp.status,
        headers: { "Content-Type": "application/json", ...corsHeaders(origin) },
      });
    }

    if (req.method === "GET" && path.startsWith("/customers/")) {
      const id = path.split("/").pop();
      const resp = await fetch(`${BRIDGE_API_BASE}/v0/customers/${id}`, {
        headers: {
          "Api-Key": BRIDGE_API_KEY,
        },
      });
      const data = await resp.text();
      return new Response(data, {
        status: resp.status,
        headers: { "Content-Type": "application/json", ...corsHeaders(origin) },
      });
    }

    return jsonResponse({ error: "not_found" }, { status: 404 }, origin);
  } catch (e) {
    // Avoid logging secrets/PII
    return jsonResponse({ error: "upstream_error" }, { status: 502 }, origin);
  }
}

Deno.serve(async (req: Request) => {
  const url = new URL(req.url);
  return handleProxy(req, url);
});
